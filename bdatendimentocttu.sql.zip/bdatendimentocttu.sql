-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 19-Out-2018 às 21:55
-- Versão do servidor: 10.1.33-MariaDB
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bdatendimentocttu`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbchamado`
--

CREATE TABLE `tbchamado` (
  `codigo` int(10) NOT NULL,
  `codtbatd` int(10) NOT NULL,
  `guiche` int(10) DEFAULT NULL,
  `atendido` binary(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tbchamado`
--

INSERT INTO `tbchamado` (`codigo`, `codtbatd`, `guiche`, `atendido`) VALUES
(1, 1, 0, 0x31),
(2, 1, 0, 0x31),
(3, 1, 7, 0x31),
(4, 1, 7, 0x31),
(5, 1, 7, 0x31),
(6, 1, 7, 0x31),
(7, 1, 8, 0x31),
(8, 1, 8, 0x31),
(9, 1, 9, 0x31),
(10, 1, 9, 0x31),
(11, 1, 1, 0x31);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbtaxi`
--

CREATE TABLE `tbtaxi` (
  `codtaxi` int(10) NOT NULL,
  `senha` varchar(200) DEFAULT NULL,
  `horachegada` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `status_chamado` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tbtaxi`
--

INSERT INTO `tbtaxi` (`codtaxi`, `senha`, `horachegada`, `status_chamado`) VALUES
(1, 'A1', '2018-10-19 11:12:15.212069', 1),
(2, 'A2', '2018-10-11 09:08:12.072329', 0),
(3, 'A3', '2018-10-11 10:17:22.737988', 0),
(4, 'A4', '2018-10-11 10:55:14.829069', 0),
(5, 'A5', '2018-10-11 16:06:19.152806', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbchamado`
--
ALTER TABLE `tbchamado`
  ADD PRIMARY KEY (`codigo`),
  ADD KEY `atendido` (`atendido`),
  ADD KEY `codtaxi` (`codtbatd`);

--
-- Indexes for table `tbtaxi`
--
ALTER TABLE `tbtaxi`
  ADD PRIMARY KEY (`codtaxi`),
  ADD KEY `status_chamado` (`status_chamado`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbchamado`
--
ALTER TABLE `tbchamado`
  MODIFY `codigo` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbtaxi`
--
ALTER TABLE `tbtaxi`
  MODIFY `codtaxi` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `tbchamado`
--
ALTER TABLE `tbchamado`
  ADD CONSTRAINT `tbchamado_ibfk_1` FOREIGN KEY (`codtbatd`) REFERENCES `tbtaxi` (`codtaxi`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
